
export class RecordNotFoundError extends Error {}