import { Tree } from '@nrwl/devkit';

export default async function (tree: Tree, schema: any) {
  console.log(schema)
}
